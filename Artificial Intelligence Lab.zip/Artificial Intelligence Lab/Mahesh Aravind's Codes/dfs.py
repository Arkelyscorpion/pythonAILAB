graph={
"A":["B","C"],
"B":["D","E"],
"D":["H","I"],
"H":["I"],
"E":["J","K"],
"J":["K"],
"K":["L"],
"C":["F","G"],
"F":["L","M"],
"G":["N","O"],
"I":["J"],
"L":["M"],
"M":["N"],
"N":["O"],
"O":[],
    }
visited=set()
def dfs(graph,visited,node):
    if node not in visited:
        print(node,end=" ")
        visited.add(node)
        for neighbour in graph[node]:
            dfs(graph,visited,neighbour)

dfs(graph,visited,"A")
