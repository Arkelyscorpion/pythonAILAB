jugs=[]
n=int(input("Enter the number of jugs"))
print("Enter the jugs quantity available")
for i in range(n):
    jugs.append(int(input()))
print("Enter the required amount in each jar seperated in space")
target=tuple(map(int,input().split()))
queue=[(0,)*n]
visited=set()
parent={(0,)*n:None}
solvable=False
while queue:
    node=queue.pop(0)
    if node in visited:
        continue
    if node == target:
        solvable=True
        break
    visited.add(node)
    for i in range(n):
        full = list(node)
        empty = list(node)
        full[i] = jugs[i]
        empty[i] = 0
        tfull=tuple(full)
        tempty=tuple(empty)
        queue.append(tfull)
        queue.append(tempty)
        if tfull not in parent.keys():
            parent[tfull] = node
        if tempty not in parent.keys():
            parent[tempty] = node
    for firstJug in range(n):
        for secondJug in range(n):
            if firstJug != secondJug:
                ns = list(node)
                qty = min(node[firstJug],jugs[secondJug]-node[secondJug]) #We can either pour until first jug is empty or second jug is full
                ns[firstJug] -= qty
                ns[secondJug] += qty
                ns = tuple(ns)
                queue.append(ns)
                if ns not in parent.keys():
                    parent[ns] = node
curr = target
path = ''
count=0
if solvable:
    while curr != None:
        count+=1
        path = str(curr) + ' -> ' + path
        curr = parent[curr]
    print(path)
    print("No of Visited Nodes =",count)
else:
    print("No Path")
        
        
