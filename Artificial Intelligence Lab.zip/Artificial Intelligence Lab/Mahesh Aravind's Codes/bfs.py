graph={
"A":["B","C"],
"B":["D","E"],
"D":["H","I"],
"H":["I"],
"E":["J","K"],
"J":["K"],
"K":["L"],
"C":["F","G"],
"F":["L","M"],
"G":["N","O"],
"I":["J"],
"L":["M"],
"M":["N"],
"N":["O"],
"O":[],
    }
visited=set()
queue=[]
def bfs(graph,visited,node):
    visited.add(node)
    queue.append(node)
    while queue:
        l=queue.pop(0)
        print(l,end=" ")
        for neighbour in graph[l]:
            if neighbour not in visited:
                visited.add(neighbour)
                queue.append(neighbour)
bfs(graph,visited,"A")
            
            
        
    
